/* =====================================================================
   AVENGERS DATA CLEANING  -  SQL SERVER (SSMS)
   Input table : dbo.avengers        (your imported raw data - never changed)
   Output table: dbo.avengers_clean  (final, analysis-ready table)
   How to use  : Select ALL (Ctrl + A) and press Execute (F5).
   ===================================================================== */

USE Avengers_Analytics;
GO
SELECT Member_ID, Name_Alias, Appearances, Is_Current, Gender, Join_Year, Name_Imputed
FROM dbo.avengers_clean
WHERE Name_Imputed = 1 OR Name_Alias LIKE 'Nicholas Fury%';
/* ---------------------------------------------------------------------
   STEP 1 - Make a staging copy with SIMPLE column names.
   Your imported column names are mixed (Name_Alias, [Full_Reserve Avengers
   Intro] ...), so we rename by column POSITION. This avoids name errors.
   Check: the first 21 columns of dbo.avengers must be in the original order
   (URL, Name, Appearances, Current?, Gender, Probationary, Full/Reserve
   Intro, Year, Years since joining, Honorary, Death1, Return1 ... Notes).
   --------------------------------------------------------------------- */
DROP TABLE IF EXISTS dbo.avengers_stage;
DROP TABLE IF EXISTS dbo.avengers_clean;

DECLARE @map TABLE (pos INT, new_name SYSNAME);
INSERT INTO @map VALUES
 (1,'Wiki_URL'),(2,'Name_Alias'),(3,'Appearances'),(4,'Is_Current'),(5,'Gender'),
 (6,'Probationary_Intro'),(7,'Full_Reserve_Intro'),(8,'Join_Year'),
 (9,'Years_Since_Joining'),(10,'Membership_Type'),
 (11,'Death1'),(12,'Return1'),(13,'Death2'),(14,'Return2'),(15,'Death3'),
 (16,'Return3'),(17,'Death4'),(18,'Return4'),(19,'Death5'),(20,'Return5'),
 (21,'Notes');

DECLARE @cols NVARCHAR(MAX), @sql NVARCHAR(MAX);

SELECT @cols = STRING_AGG(
           'CAST(' + QUOTENAME(c.COLUMN_NAME) + ' AS NVARCHAR(1000)) AS ' + m.new_name, ', ')
       WITHIN GROUP (ORDER BY c.ORDINAL_POSITION)
FROM INFORMATION_SCHEMA.COLUMNS AS c
JOIN @map AS m ON m.pos = c.ORDINAL_POSITION
WHERE c.TABLE_SCHEMA = 'dbo' AND c.TABLE_NAME = 'avengers';

SET @sql = N'SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Member_ID, '
         + @cols
         + N', CAST(0 AS BIT) AS Name_Imputed
            INTO dbo.avengers_stage
            FROM dbo.avengers;';
EXEC sp_executesql @sql;
GO

-- Quick look: every column should now have a simple name
SELECT TOP 5 * FROM dbo.avengers_stage;
GO


/* ---------------------------------------------------------------------
   STEP 2 - Remove extra spaces, turn blanks into NULL, make YES/NO uppercase
   --------------------------------------------------------------------- */
UPDATE dbo.avengers_stage
SET Wiki_URL            = NULLIF(LTRIM(RTRIM(Wiki_URL)), ''),
    Name_Alias          = NULLIF(LTRIM(RTRIM(Name_Alias)), ''),
    Appearances         = NULLIF(LTRIM(RTRIM(Appearances)), ''),
    Is_Current          = UPPER(NULLIF(LTRIM(RTRIM(Is_Current)), '')),
    Gender              = UPPER(NULLIF(LTRIM(RTRIM(Gender)), '')),
    Probationary_Intro  = NULLIF(LTRIM(RTRIM(Probationary_Intro)), ''),
    Full_Reserve_Intro  = NULLIF(LTRIM(RTRIM(Full_Reserve_Intro)), ''),
    Join_Year           = NULLIF(LTRIM(RTRIM(Join_Year)), ''),
    Years_Since_Joining = NULLIF(LTRIM(RTRIM(Years_Since_Joining)), ''),
    Membership_Type     = NULLIF(LTRIM(RTRIM(Membership_Type)), ''),
    Death1 = UPPER(NULLIF(LTRIM(RTRIM(Death1)), '')), Return1 = UPPER(NULLIF(LTRIM(RTRIM(Return1)), '')),
    Death2 = UPPER(NULLIF(LTRIM(RTRIM(Death2)), '')), Return2 = UPPER(NULLIF(LTRIM(RTRIM(Return2)), '')),
    Death3 = UPPER(NULLIF(LTRIM(RTRIM(Death3)), '')), Return3 = UPPER(NULLIF(LTRIM(RTRIM(Return3)), '')),
    Death4 = UPPER(NULLIF(LTRIM(RTRIM(Death4)), '')), Return4 = UPPER(NULLIF(LTRIM(RTRIM(Return4)), '')),
    Death5 = UPPER(NULLIF(LTRIM(RTRIM(Death5)), '')), Return5 = UPPER(NULLIF(LTRIM(RTRIM(Return5)), '')),
    Notes               = NULLIF(LTRIM(RTRIM(Notes)), '');
GO


/* ---------------------------------------------------------------------
   STEP 3 - Fix the ONE broken row (Nicholas Fury Jr.)
   His name contains commas, so every value slid to the wrong column.
   We find him by URL and put each value back in the right place.
   --------------------------------------------------------------------- */
UPDATE dbo.avengers_stage
SET Wiki_URL            = 'http://marvel.wikia.com/Nicholas_Fury_Jr._(Earth-616)#',
    Name_Alias          = 'Nicholas Fury, Jr., Marcus Johnson',
    Appearances         = '77',
    Is_Current          = 'YES',
    Gender              = 'MALE',
    Probationary_Intro  = NULL,
    Full_Reserve_Intro  = NULL,        -- this date was damaged by Excel
    Join_Year           = '2013',
    Years_Since_Joining = '2',
    Membership_Type     = 'Full',
    Death1              = 'NO',
    Return1             = NULL
WHERE Wiki_URL LIKE '%Nicholas_Fury%'
  AND (Gender IS NULL OR Gender NOT IN ('MALE', 'FEMALE'));   -- only if still broken
GO


/* ---------------------------------------------------------------------
   STEP 4 - Fill the 10 missing names using the URL
   Example: .../Gilgamesh_(Earth-616)#  ->  Gilgamesh
   --------------------------------------------------------------------- */
UPDATE s
SET s.Name_Alias   = REPLACE(
                        CASE WHEN CHARINDEX('_(', t.Tail) > 0
                             THEN LEFT(t.Tail, CHARINDEX('_(', t.Tail) - 1)
                             ELSE t.Tail END, '_', ' '),
    s.Name_Imputed = 1
FROM dbo.avengers_stage AS s
CROSS APPLY (SELECT RIGHT(s.Wiki_URL, CHARINDEX('/', REVERSE(s.Wiki_URL)) - 1) AS Tail) AS t
WHERE s.Name_Alias IS NULL
  AND s.Wiki_URL   IS NOT NULL;
GO


/* ---------------------------------------------------------------------
   STEP 5 - Build the FINAL clean table
     * 1900 (fake year)          -> NULL
     * Tenure                    -> 2015 minus join year
     * Death / Return columns    -> simple counts and 1/0 flags
     * Damaged intro dates and the empty last column are NOT carried over
   --------------------------------------------------------------------- */
DECLARE @snapshot_year INT = 2015;

WITH base AS (
    SELECT *,
           NULLIF(TRY_CAST(TRY_CAST(Join_Year AS FLOAT) AS INT), 1900) AS JY,
           CASE WHEN Death1  = 'YES' THEN 1 ELSE 0 END + CASE WHEN Death2  = 'YES' THEN 1 ELSE 0 END
         + CASE WHEN Death3  = 'YES' THEN 1 ELSE 0 END + CASE WHEN Death4  = 'YES' THEN 1 ELSE 0 END
         + CASE WHEN Death5  = 'YES' THEN 1 ELSE 0 END AS DC,
           CASE WHEN Return1 = 'YES' THEN 1 ELSE 0 END + CASE WHEN Return2 = 'YES' THEN 1 ELSE 0 END
         + CASE WHEN Return3 = 'YES' THEN 1 ELSE 0 END + CASE WHEN Return4 = 'YES' THEN 1 ELSE 0 END
         + CASE WHEN Return5 = 'YES' THEN 1 ELSE 0 END AS RC
    FROM dbo.avengers_stage
)
SELECT
    Member_ID,
    Name_Alias,
    Wiki_URL,
    Gender,
    Membership_Type,
    CASE Is_Current WHEN 'YES' THEN 1 WHEN 'NO' THEN 0 END                    AS Is_Current,
    TRY_CAST(TRY_CAST(Appearances AS FLOAT) AS INT)                           AS Appearances,
    JY                                                                        AS Join_Year,
    @snapshot_year - JY                                                       AS Tenure_Years,
    CASE WHEN JY IS NULL THEN 1 ELSE 0 END                                    AS Join_Year_Missing,
    CASE WHEN Probationary_Intro IS NOT NULL THEN 1 ELSE 0 END                AS Is_Probationary,
    DC                                                                        AS Death_Count,
    RC                                                                        AS Return_Count,
    CASE WHEN DC > RC THEN DC - RC ELSE 0 END                                 AS Unreturned_Deaths,
    CASE WHEN DC >= 1 THEN 1 ELSE 0 END                                       AS Ever_Died,
    CASE WHEN DC >= 2 THEN 1 ELSE 0 END                                       AS Is_Multi_Death,
    CASE WHEN DC >= 1 AND RC >= 1 THEN 1 ELSE 0 END                           AS Is_Resurrected,
    Name_Imputed,
    Notes
INTO dbo.avengers_clean
FROM base;
GO


/* ---------------------------------------------------------------------
   STEP 6 - Check the result (each query opens in its own result tab)
   --------------------------------------------------------------------- */

-- 6a. Row counts must match (expect 173 and 173)
SELECT (SELECT COUNT(*) FROM dbo.avengers)       AS Raw_Rows,
       (SELECT COUNT(*) FROM dbo.avengers_clean) AS Clean_Rows;

-- 6b. Important columns must have no blanks (expect all 0)
SELECT SUM(CASE WHEN Name_Alias      IS NULL THEN 1 ELSE 0 END) AS Null_Name,
       SUM(CASE WHEN Gender          IS NULL THEN 1 ELSE 0 END) AS Null_Gender,
       SUM(CASE WHEN Is_Current      IS NULL THEN 1 ELSE 0 END) AS Null_Current,
       SUM(CASE WHEN Appearances     IS NULL THEN 1 ELSE 0 END) AS Null_Appearances,
       SUM(CASE WHEN Membership_Type IS NULL THEN 1 ELSE 0 END) AS Null_Membership
FROM dbo.avengers_clean;

-- 6c. Allowed values only (MALE / FEMALE and the 4 membership types)
SELECT Gender, COUNT(*) AS Members FROM dbo.avengers_clean GROUP BY Gender;
SELECT Membership_Type, COUNT(*) AS Members FROM dbo.avengers_clean GROUP BY Membership_Type;

-- 6d. Join years: 1963 to 2015, and 14 unknown years
SELECT MIN(Join_Year) AS First_Year, MAX(Join_Year) AS Last_Year,
       SUM(Join_Year_Missing) AS Unknown_Join_Year,
       MIN(Tenure_Years) AS Min_Tenure, MAX(Tenure_Years) AS Max_Tenure
FROM dbo.avengers_clean;

-- 6e. Returns can never be more than deaths (expect no rows)
SELECT Member_ID, Name_Alias, Death_Count, Return_Count
FROM dbo.avengers_clean
WHERE Return_Count > Death_Count;

-- 6f. Duplicate URLs (expect no rows)
SELECT Wiki_URL, COUNT(*) AS Times
FROM dbo.avengers_clean
GROUP BY Wiki_URL
HAVING COUNT(*) > 1;

-- 6g. Summary for the BRD
SELECT COUNT(*)            AS Total_Members,
       SUM(Is_Current)     AS Active_Members,
       SUM(Ever_Died)      AS Members_Who_Died,
       SUM(Is_Resurrected) AS Resurrected_Members,
       SUM(Is_Multi_Death) AS Died_More_Than_Once
FROM dbo.avengers_clean;

-- 6h. Final table
SELECT * FROM dbo.avengers_clean ORDER BY Member_ID;
GO

-- Optional: remove the staging table once you are happy with the result
-- DROP TABLE IF EXISTS dbo.avengers_stage;